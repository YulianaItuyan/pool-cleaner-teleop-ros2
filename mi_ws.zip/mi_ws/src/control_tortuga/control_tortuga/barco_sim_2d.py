#!/usr/bin/env python3
import math
import rclpy
from rclpy.node import Node

from geometry_msgs.msg import Twist, TransformStamped
from tf2_ros import TransformBroadcaster


class BarcoSim2D(Node):
    def __init__(self):
        super().__init__('barco_sim_2d')

        # Parámetros
        self.declare_parameter('frame_id', 'world')
        self.declare_parameter('child_frame_id', 'base_link')
        self.declare_parameter('update_rate', 50.0)  # Hz

        self.frame_id = self.get_parameter('frame_id').get_parameter_value().string_value
        self.child_frame_id = self.get_parameter('child_frame_id').get_parameter_value().string_value
        self.rate = self.get_parameter('update_rate').get_parameter_value().double_value

        # Suscriptor a velocidad del barco
        self.twist_sub = self.create_subscription(
            Twist,
            '/barco/cmd_vel',
            self.twist_callback,
            10
        )

        # Publicador de TF
        self.br = TransformBroadcaster(self)

        # Estado en 2D
        self.x = 0.0
        self.y = 0.0
        self.theta = 0.0

        self.last_time = self.get_clock().now()

        # Últimos comandos
        self.v = 0.0  # linear.x
        self.w = 0.0  # angular.z

        self.timer = self.create_timer(1.0 / self.rate, self.update)

        self.get_logger().info('barco_sim_2d listo (publica TF world → base_link).')

    def twist_callback(self, msg: Twist):
        self.v = msg.linear.x
        self.w = msg.angular.z

    def update(self):
        now = self.get_clock().now()
        dt = (now - self.last_time).nanoseconds * 1e-9
        self.last_time = now

        # Integración simple
        self.x += self.v * math.cos(self.theta) * dt
        self.y += self.v * math.sin(self.theta) * dt
        self.theta += self.w * dt
        self.theta = math.atan2(math.sin(self.theta), math.cos(self.theta))

        # Publicar TF
        t = TransformStamped()
        t.header.stamp = now.to_msg()
        t.header.frame_id = self.frame_id
        t.child_frame_id = self.child_frame_id

        t.transform.translation.x = float(self.x)
        t.transform.translation.y = float(self.y)
        t.transform.translation.z = 0.0

        qz = math.sin(self.theta / 2.0)
        qw = math.cos(self.theta / 2.0)
        t.transform.rotation.x = 0.0
        t.transform.rotation.y = 0.0
        t.transform.rotation.z = qz
        t.transform.rotation.w = qw

        self.br.sendTransform(t)


def main(args=None):
    rclpy.init(args=args)
    node = BarcoSim2D()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()

