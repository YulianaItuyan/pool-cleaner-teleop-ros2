import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist

import sys
import select
import termios
import tty

INSTRUCTIONS = """
Control por teclado para turtlesim
----------------------------------
Movimiento:
    w : adelante
    s : atrás
    a : girar a la izquierda
    d : girar a la derecha
    espacio : detener

Salir:
    q : salir del nodo
"""


def get_key(settings):
    tty.setraw(sys.stdin.fileno())
    rlist, _, _ = select.select([sys.stdin], [], [], 0.1)
    key = ''
    if rlist:
        key = sys.stdin.read(1)
    termios.tcsetattr(sys.stdin.fileno(), termios.TCSADRAIN, settings)
    return key


class TecladoTeleopTurtle(Node):
    def __init__(self):
        super().__init__('teclado_teleop_turtle')

        self.pub = self.create_publisher(Twist, 'turtle1/cmd_vel', 10)

        self.linear_speed = 2.0
        self.angular_speed = 4.0

        self.get_logger().info('Nodo TecladoTeleopTurtle iniciado')
        print(INSTRUCTIONS)

    def loop(self):
        settings = termios.tcgetattr(sys.stdin)
        try:
            twist = Twist()
            while rclpy.ok():
                key = get_key(settings)

                if key == 'w':
                    twist.linear.x = self.linear_speed
                    twist.angular.z = 0.0
                elif key == 's':
                    twist.linear.x = -self.linear_speed
                    twist.angular.z = 0.0
                elif key == 'a':
                    twist.linear.x = 0.0
                    twist.angular.z = self.angular_speed
                elif key == 'd':
                    twist.linear.x = 0.0
                    twist.angular.z = -self.angular_speed
                elif key == ' ':
                    twist.linear.x = 0.0
                    twist.angular.z = 0.0
                elif key == 'q':
                    # salir
                    twist = Twist()
                    self.pub.publish(twist)
                    break
                else:
                    # Si no se presiona nada relevante, no cambiamos el comando
                    pass

                self.pub.publish(twist)
        finally:
            # restaurar terminal
            termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)


def main(args=None):
    rclpy.init(args=args)
    node = TecladoTeleopTurtle()
    try:
        node.loop()
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()

