import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Joy
from geometry_msgs.msg import Twist


class PS4TeleopTurtle(Node):
    def __init__(self):
        super().__init__('ps4_teleop_turtle')

        # ====== CONFIGURACIÓN DE EJES ======
        # OJO: estos índices son 0-based como en /joy.axes
        # Si en jstest o en ros2 topic echo /joy tus Axis son:
        #   AXIS 1 -> axes[1]
        #   AXIS 2 -> axes[2]
        #   AXIS 3 -> axes[3]
        #   AXIS 5 -> axes[5]
        # entonces usamos:
        self.AXIS_ROT = 1   # AXIS 1: girar tortuga (angular.z)
        self.AXIS_LIN = 3   # AXIS 3: marcha/retroceso (linear.x)
        self.AXIS_PEND1 = 2 # AXIS 2: pendiente (futuro uso)
        self.AXIS_PEND2 = 5 # AXIS 5: pendiente (futuro uso)

        # Suscriptor al joystick
        self.joy_sub = self.create_subscription(
            Joy,
            'joy',
            self.joy_callback,
            10
        )

        # Publicador a la tortuga
        self.cmd_pub = self.create_publisher(
            Twist,
            'turtle1/cmd_vel',
            10
        )

        # Ganancias
        self.linear_gain = 2.0   # velocidad lineal máxima
        self.angular_gain = 4.0  # velocidad angular máxima

        # Deadzone (para que pequeños ruidos no muevan la tortuga)
        self.deadzone = 0.1

        self.get_logger().info('PS4TeleopTurtle iniciado con mapeo personalizado.')

    def aplicar_deadzone(self, valor: float) -> float:
        """Devuelve 0 si el valor está dentro de la deadzone."""
        if abs(valor) < self.deadzone:
            return 0.0
        return valor

    def joy_callback(self, msg: Joy):
        axes = msg.axes

        # Comprobamos que existan suficientes ejes
        max_index = max(self.AXIS_ROT, self.AXIS_LIN, self.AXIS_PEND1, self.AXIS_PEND2)
        if len(axes) <= max_index:
            self.get_logger().warn(
                f'Mensaje Joy con pocos ejes: len(axes)={len(axes)}, se requiere al menos {max_index+1}.'
            )
            return

        # Leemos los ejes
        raw_rot   = axes[self.AXIS_ROT]    # AXIS 1
        raw_lin   = axes[self.AXIS_LIN]    # AXIS 3
        raw_pend1 = axes[self.AXIS_PEND1]  # AXIS 2 (pendiente)
        raw_pend2 = axes[self.AXIS_PEND2]  # AXIS 5 (pendiente)

        # Aplicamos deadzone
        rot_val = self.aplicar_deadzone(raw_rot)
        lin_val = self.aplicar_deadzone(raw_lin)

        # IMPORTANTE:
        # Muchos mandos tienen:
        #   - hacia adelante = -1
        #   - hacia atrás    = +1
        # por eso se suele poner un signo (-) en la velocidad lineal
        linear  = -lin_val * self.linear_gain
        angular =  rot_val * self.angular_gain  # aquí puedes invertir signo si gira al revés

        cmd = Twist()
        cmd.linear.x  = float(linear)
        cmd.angular.z = float(angular)

        self.cmd_pub.publish(cmd)

        # Log de depuración (incluye los ejes pendientes para ver qué hacen)
        self.get_logger().info(
            f'AX1(rot)={raw_rot:+.2f}  AX3(lin)={raw_lin:+.2f}  '
            f'AX2(pend)={raw_pend1:+.2f}  AX5(pend)={raw_pend2:+.2f}  '
            f'=> cmd: lin={cmd.linear.x:+.2f}, ang={cmd.angular.z:+.2f}'
        )


def main(args=None):
    rclpy.init(args=args)
    node = PS4TeleopTurtle()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()

