import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist


class MonitorTurtleCmd(Node):
    def __init__(self):
        super().__init__('monitor_turtle_cmd')

        self.sub = self.create_subscription(
            Twist,
            'turtle1/cmd_vel',
            self.callback,
            10
        )

        self.get_logger().info('MonitorTurtleCmd suscrito a /turtle1/cmd_vel')

    def callback(self, msg: Twist):
        self.get_logger().info(
            f'Cmd_vel -> linear.x={msg.linear.x:.2f}, angular.z={msg.angular.z:.2f}'
        )


def main(args=None):
    rclpy.init(args=args)
    node = MonitorTurtleCmd()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()

