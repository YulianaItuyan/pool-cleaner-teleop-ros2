import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Joy
from geometry_msgs.msg import Twist


class PS4TeleopBarco(Node):
    def __init__(self):
        super().__init__('ps4_teleop_barco')

        # ====== CONFIGURACIÓN DE EJES ======
        # Igual que con la tortuga:
        #   AXIS 1 -> giro (angular.z)
        #   AXIS 3 -> adelante/atrás (linear.x)
        self.AXIS_ROT = 1   # joystick izquierdo horizontal (según tu mando)
        self.AXIS_LIN = 3   # joystick derecho vertical
        self.deadzone = 0.1

        # Ganancias de velocidad
        self.linear_gain = 0.5    # m/s aprox
        self.angular_gain = 0.8   # rad/s aprox

        # Suscriptor al joystick
        self.joy_sub = self.create_subscription(
            Joy,
            'joy',
            self.joy_callback,
            10
        )

        # Publicador al barco en Gazebo
        # OJO: este topic debe coincidir con el remapping del plugin:
        # <namespace>/cmd_vel_barco  → /barco/cmd_vel_barco
        self.cmd_pub = self.create_publisher(
            Twist,
            '/barco/cmd_vel_barco',
            10
        )

        self.get_logger().info('PS4TeleopBarco iniciado. Publicando en /barco/cmd_vel_barco')

    def aplicar_deadzone(self, valor: float) -> float:
        if abs(valor) < self.deadzone:
            return 0.0
        return valor

    def joy_callback(self, msg: Joy):
        axes = msg.axes

        # Seguridad: verificar que existan los ejes necesarios
        max_index = max(self.AXIS_ROT, self.AXIS_LIN)
        if len(axes) <= max_index:
            self.get_logger().warn(
                f'Mensaje Joy con pocos ejes: len(axes)={len(axes)}, '
                f'se requiere al menos {max_index+1}.'
            )
            return

        raw_rot = axes[self.AXIS_ROT]
        raw_lin = axes[self.AXIS_LIN]

        rot_val = self.aplicar_deadzone(raw_rot)
        lin_val = self.aplicar_deadzone(raw_lin)

        # Muchos mandos: hacia adelante = -1, atrás = +1
        linear  = -lin_val * self.linear_gain
        angular =  rot_val * self.angular_gain

        cmd = Twist()
        cmd.linear.x  = float(linear)
        cmd.angular.z = float(angular)

        self.cmd_pub.publish(cmd)

        self.get_logger().info(
            f'AX_ROT={raw_rot:+.2f}  AX_LIN={raw_lin:+.2f} '
            f'=> cmd: lin={cmd.linear.x:+.2f}, ang={cmd.angular.z:+.2f}'
        )


def main(args=None):
    rclpy.init(args=args)
    node = PS4TeleopBarco()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
