#!/usr/bin/env python3
import rclpy
from rclpy.node import Node

from sensor_msgs.msg import Joy, JointState
from geometry_msgs.msg import Twist


class PS4TeleopBarco(Node):
    def __init__(self):
        super().__init__('ps4_teleop_barco')

        # ==== MISMOS EJES QUE LA TORTUGA ====
        # De tu código:
        #   AXIS 1 -> rotación
        #   AXIS 3 -> marcha/retroceso
        #   AXIS 2 y 5 -> pendientes (los dejamos por si luego los usas)
        self.AXIS_ROT = 1    # AXIS 1: girar (angular.z y aletas)
        self.AXIS_LIN = 3    # AXIS 3: adelante/atrás (linear.x)
        self.AXIS_PEND1 = 2  # AXIS 2
        self.AXIS_PEND2 = 5  # AXIS 5

        # Ganancias del barco
        self.linear_gain = 0.5    # m/s aprox
        self.angular_gain = 1.0   # rad/s aprox
        self.fin_gain = 0.7       # rad (~40°) para ángulo máximo de las aletas

        # Deadzone igual que en la tortuga
        self.deadzone = 0.1

        # Suscriptor al joystick
        self.joy_sub = self.create_subscription(
            Joy,
            'joy',
            self.joy_callback,
            10
        )

        # Publicador de velocidad del barco (para la simulación 2D)
        self.cmd_pub = self.create_publisher(
            Twist,
            '/barco/cmd_vel',
            10
        )

        # Publicador de estados de juntas (para robot_state_publisher)
        self.joint_pub = self.create_publisher(
            JointState,
            '/joint_states',
            10
        )

        self.get_logger().info('PS4TeleopBarco iniciado (mapea ejes igual que la tortuga).')

    def aplicar_deadzone(self, valor: float) -> float:
        """Devuelve 0 si el valor está dentro de la deadzone."""
        if abs(valor) < self.deadzone:
            return 0.0
        return valor

    def joy_callback(self, msg: Joy):
        axes = msg.axes

        # Comprobamos que existan suficientes ejes
        max_index = max(self.AXIS_ROT, self.AXIS_LIN, self.AXIS_PEND1, self.AXIS_PEND2)
        if len(axes) <= max_index:
            self.get_logger().warn(
                f'Mensaje Joy con pocos ejes: len(axes)={len(axes)}, se requiere al menos {max_index+1}.'
            )
            return

        # ====== Lectura de ejes ======
        raw_rot   = axes[self.AXIS_ROT]    # AXIS 1
        raw_lin   = axes[self.AXIS_LIN]    # AXIS 3
        raw_pend1 = axes[self.AXIS_PEND1]  # AXIS 2 (pendiente)
        raw_pend2 = axes[self.AXIS_PEND2]  # AXIS 5 (pendiente)

        # Deadzone
        rot_val = self.aplicar_deadzone(raw_rot)
        lin_val = self.aplicar_deadzone(raw_lin)

        # Igual que en la tortuga: muchos mandos son -1 adelante, +1 atrás
        linear  = -lin_val * self.linear_gain   # adelante = stick hacia arriba
        angular =  rot_val * self.angular_gain  # puedes cambiar signo si gira al revés

        # ====== Publicar Twist del barco ======
        cmd = Twist()
        cmd.linear.x  = float(linear)
        cmd.linear.y  = 0.0
        cmd.linear.z  = 0.0
        cmd.angular.x = 0.0
        cmd.angular.y = 0.0
        cmd.angular.z = float(angular)

        self.cmd_pub.publish(cmd)

        # ====== Publicar JointStates de las aletas ======
        # Usamos el mismo eje de giro (AXIS 1) para inclinar aletas
        fin_angle = rot_val * self.fin_gain

        js = JointState()
        js.header.stamp = self.get_clock().now().to_msg()

        # Nombres EXACTOS como en tu URDF
        js.name = [
            'Empty_Rueda_derecha_joint',
            'Empty_Rueda_Izquierda_joint',
            # opcional: incluimos también los servos, por ahora en 0
            'Empty_derecha_joint',
            'Empty_izquierda_joint',
        ]
        js.position = [
            float(fin_angle),   # aleta derecha
            float(fin_angle),   # aleta izquierda
            0.0,                # servo derecho fijo
            0.0,                # servo izquierdo fijo
        ]

        self.joint_pub.publish(js)

        # Log de depuración
        self.get_logger().info(
            f'AX1(rot)={raw_rot:+.2f}  AX3(lin)={raw_lin:+.2f}  '
            f'AX2(pend)={raw_pend1:+.2f}  AX5(pend)={raw_pend2:+.2f}  '
            f'=> barco: lin={cmd.linear.x:+.2f}, ang={cmd.angular.z:+.2f}, '
            f'fin={fin_angle:+.2f}'
        )


def main(args=None):
    rclpy.init(args=args)
    node = PS4TeleopBarco()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()

