from setuptools import setup

package_name = 'control_tortuga'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
         ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='yituyan',
    maintainer_email='unknown@todo.todo',
    description='Teleop de turtlesim con joystick PS4 y teclado',
    license='Apache License 2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'ps4_teleop_turtle = control_tortuga.ps4_teleop_turtle:main',
            'monitor_turtle_cmd = control_tortuga.monitor_turtle_cmd:main',
            'teclado_teleop_turtle = control_tortuga.teclado_teleop_turtle:main', 'ps4_teleop_barco = control_tortuga.ps4_teleop_barco:main',
        'barco_sim_2d = control_tortuga.barco_sim_2d:main',
        ],
    },
)

