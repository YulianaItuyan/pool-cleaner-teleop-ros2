from setuptools import setup
from glob import glob
import os

package_name = 'barco_description'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    data_files=[
        # Índice de ament
        ('share/ament_index/resource_index/packages',
         ['resource/' + package_name]),

        # package.xml
        ('share/' + package_name, ['package.xml']),

        # URDF
        (os.path.join('share', package_name, 'urdf'),
         glob('urdf/*')),

        # Meshes
        (os.path.join('share', package_name, 'meshes'),
         glob('meshes/*')),

        # Launch files
        (os.path.join('share', package_name, 'launch'),
         glob('launch/*.py')),

        # 🌊 Worlds para Gazebo
        (os.path.join('share', package_name, 'worlds'),
         glob('worlds/*')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Yuliana',
    maintainer_email='yuli@example.com',
    description='Descripción y URDF del barco para RViz y Gazebo',
    license='BSD',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [],
    },
)

