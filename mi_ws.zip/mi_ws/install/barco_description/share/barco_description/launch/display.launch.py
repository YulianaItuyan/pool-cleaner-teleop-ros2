from launch import LaunchDescription
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory
import os


def generate_launch_description():
    pkg_path = get_package_share_directory('barco_description')
    urdf_path = os.path.join(pkg_path, 'urdf', 'BarcoCompleto.urdf')

    # Leemos el URDF
    with open(urdf_path, 'r') as urdf_file:
        robot_description = urdf_file.read()

    # Publica robot_description y los TF internos (joints)
    robot_state_publisher_node = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher',
        output='screen',
        parameters=[{'robot_description': robot_description}]
    )

    # GUI para joint states (no molesta, aunque el barco no tenga muchas juntas activas)
    joint_state_publisher_node = Node(
        package='joint_state_publisher_gui',
        executable='joint_state_publisher_gui',
        name='joint_state_publisher_gui',
        output='screen'
    )

    # TF estático: world -> base_link
    static_tf_node = Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        name='world_to_base_link',
        arguments=['0', '0', '0',      # x y z
                   '0', '0', '0',      # roll pitch yaw
                   'world', 'base_link']
    )

    # RViz con el mismo parámetro robot_description
    rviz_node = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        output='screen',
        parameters=[{'robot_description': robot_description}]
    )

    return LaunchDescription([
        static_tf_node,
        robot_state_publisher_node,
        joint_state_publisher_node,
        rviz_node
    ])

