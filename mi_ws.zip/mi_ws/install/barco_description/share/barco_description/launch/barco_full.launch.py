from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory
import os


def generate_launch_description():
    # 1) Launch que ya tienes para RViz + robot_state_publisher
    barco_description_share = get_package_share_directory('barco_description')
    display_launch = os.path.join(
        barco_description_share,
        'launch',
        'display.launch.py'
    )

    display_rviz = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(display_launch)
    )

    # 2) Nodo de la tortuga (2D)
    turtlesim = Node(
        package='turtlesim',
        executable='turtlesim_node',
        name='turtlesim'
    )

    # 3) Nodo del joystick (PS4) -> /joy
    joy_node = Node(
    package='joy',
    executable='joy_node',
    name='joy_node',
    output='screen',
    parameters=[
        {'dev': '/dev/input/js0'},
        {'deadzone': 0.05},
        {'autorepeat_rate': 20.0}
    ]
)


    # 4) Nodo que tú hiciste: PS4 -> aletas + tortuga
    ps4_teleop_barco = Node(
        package='control_tortuga',     # <- tu paquete
        executable='ps4_teleop_barco', # <- tu ejecutable
        name='ps4_teleop_barco',
        output='screen'
    )

    return LaunchDescription([
        display_rviz,      # RViz + barco
        turtlesim,         # Tortuga 2D
        joy_node,          # Lectura del mando
        ps4_teleop_barco   # Teleop: mueve aletas + turtle1
    ])

