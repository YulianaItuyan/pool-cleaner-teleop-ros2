from launch import LaunchDescription
from launch.actions import ExecuteProcess
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory
import os


def generate_launch_description():
    pkg_barco = get_package_share_directory('barco_description')

    # Mundo con agua
    world_file = os.path.join(pkg_barco, 'worlds', 'piscina.sdf')

    # URDF del barco (el mismo que usas en RViz)
    urdf_file = os.path.join(pkg_barco, 'urdf', 'BarcoCompleto.urdf')
    with open(urdf_file, 'r') as f:
        robot_desc = f.read()

    # 1) Servidor de Gazebo + plugin de ROS (factory)
    gzserver = ExecuteProcess(
        cmd=[
            'gzserver',
            world_file,
            '--verbose',
            '-s', 'libgazebo_ros_init.so',
            '-s', 'libgazebo_ros_factory.so',
        ],
        output='screen'
    )

    # 2) Cliente (ventana gráfica)
    gzclient = ExecuteProcess(
        cmd=['gzclient'],
        output='screen'
    )

    # 3) Publicar /robot_description desde el URDF
    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher_barco',
        output='screen',
        parameters=[{'robot_description': robot_desc}]
    )

    # 4) Spawnear el barco leyendo /robot_description
    spawn_barco = Node(
    package='gazebo_ros',
    executable='spawn_entity.py',
    name='spawn_barco',
    output='screen',
    arguments=[
        '-entity', 'barco',
        '-topic', 'robot_description',
        '-x', '0', '-y', '0', '-z', '0.2'
    ]
)

    return LaunchDescription([
        gzserver,
        gzclient,
        robot_state_publisher,
        spawn_barco
    ])
