from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory
import os


def generate_launch_description():
    # Directorio del paquete
    pkg_barco = get_package_share_directory('barco_description')

    # Ruta al URDF (el que ya sabes que está bien y se ve en RViz)
    urdf_file = os.path.join(pkg_barco, 'urdf', 'BarcoCompleto.urdf')
    with open(urdf_file, 'r') as f:
        robot_desc = f.read()

    # 1) Lanzar Gazebo classic con mundo vacío
    gazebo_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(
                get_package_share_directory('gazebo_ros'),
                'launch',
                'gazebo.launch.py'
            )
        ),
        launch_arguments={
            'verbose': 'true',
            # no ponemos 'world', usa empty.world por defecto
        }.items()
    )

    # 2) Publicar /robot_description y las TF del barco
    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher_barco',
        output='screen',
        parameters=[{'robot_description': robot_desc}]  # 👈 LISTA con dict
    )

    # 3) Spawnear el barco en Gazebo leyendo /robot_description
    spawn_barco = Node(
        package='gazebo_ros',
        executable='spawn_entity.py',
        name='spawn_barco',
        output='screen',
        arguments=[
            '-entity', 'barco',
            '-topic', 'robot_description',
            '-x', '0', '-y', '0', '-z', '0.2'
        ]
    )

    return LaunchDescription([
        gazebo_launch,
        robot_state_publisher,
        spawn_barco
    ])

