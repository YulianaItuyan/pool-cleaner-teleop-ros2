from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory
import os


def generate_launch_description():
    pkg_barco = get_package_share_directory('barco_description')
    urdf_file = os.path.join(pkg_barco, 'urdf', 'BarcoCompleto.urdf')

    # Leer el URDF (sin la línea <?xml ...?>)
    with open(urdf_file, 'r') as f:
        robot_description = f.read()

    # 1) Lanzar Gazebo **clásico** con el mundo por defecto (empty.world)
    gazebo_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(
                get_package_share_directory('gazebo_ros'),
                'launch',
                'gazebo.launch.py'
            )
        ),
        # SIN pasarle world => usa worlds/empty.world, que es muy liviano
        # launch_arguments={} también valdría, pero lo dejo explícito
        launch_arguments={}.items(),
    )

    # 2) Publicar el URDF en /robot_description
    robot_state_pub = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher_barco',
        output='screen',
        parameters=[{'robot_description': robot_description}],
    )

    # 3) Spawnear el barco en Gazebo desde /robot_description
    spawn_barco = Node(
        package='gazebo_ros',
        executable='spawn_entity.py',
        name='spawn_barco',
        output='screen',
        arguments=[
            '-topic', 'robot_description',
            '-entity', 'barco',
            '-x', '0.0',
            '-y', '0.0',
            '-z', '0.2',   # un pelín elevado para que no se clave en el suelo
        ],
    )

    return LaunchDescription([
        gazebo_launch,
        robot_state_pub,
        spawn_barco,
    ])

